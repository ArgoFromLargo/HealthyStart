import java.util.*;

public class User
{

    private	String id;
    private String address;	//maybe do an address object?
    private String name;
    private String phone;
    //private List<Appointment> aptList;


    public User()
    {
        id="";
        address="";
        name="";
        phone="";
        //aptList = new List<Appointment>();
    }

    public User(String email, String add, String fullName, String phoneNum)
    {
        id = email;
        address = add;
        name = fullName;
        phone  = phoneNum;
    }
    public String getEmail()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public String getPhone()
    {
        return phone;
    }

    public String getAddress()
    {
        return address;
    }

    public void setEmail(String email)
    {
        id = email;
    }

    public void setName(String userName)
    {
        name = userName;
    }

    public void setAddress(String home)
    {
        address = home;
    }

    public void setPhone(String phoneNum)
    {
        phone = phoneNum;
    }

}
