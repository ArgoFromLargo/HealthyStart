/**
 * Created by jayz2053 on 4/9/17.
 */
public class Finaltest {

    public static void main(String[] args) {

        CompleteUser finaltest = new CompleteUser("dumptruck@yahoo.com");
        User testUser = finaltest.getFinalProduct();

        testUser.printHistory();

    }
}
